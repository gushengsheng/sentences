# sentences · v1.0

把一篇文本切成句子战场。每一句都可能被悄悄换成错误的说法，你占领、识破、修正——读得懂，才打得赢。

![对局界面](docs/ui-game.png)

## 规则速览

| 项 | 规则 |
|---|---|
| 棋盘 | 文本按原句切成的「句元」，没有邻接限制，任意可点 |
| 句元属性 | 归属（无主 / A / B）、正确性（正确 / 错误） |
| 收入 | 每回合 `max(1, 1 + 己方正确数 − 己方错误数)` |
| 占领 | 1 AP，揭示并归己方 |
| 修正 | 1 AP，4 选 1；选对变正确，**选错会把句子改错** |
| 转化 | 2 AP，把对方句元打回无主 |
| 放弃 | 0 AP，丢掉己方句元 |
| 腐化脉冲 | 每 3 轮结束，己方每个正确句元有 1/4 概率变错，无提示 |
| 胜负 | 到指定轮数后，比较「下一轮会到账的 AP」，多者胜；平局先手胜 |

## 运行

```powershell
npm install --include=dev
npm run dev
```

打开 `http://127.0.0.1:5175/`。

手机访问：服务监听 `0.0.0.0`，手机连同一 Wi-Fi，打开 `http://<电脑IP>:5175/`。

也可以双击 `启动游戏.cmd`。

## 构建与部署

```powershell
npm run build
npx vite preview --host 0.0.0.0 --port 4173
```

`dist/` 是纯静态产物，可以丢到任何静态服务器。注意生产构建没有热更新，改代码后要重新 build。

## 当前内容

| 地图包 | 战区 | 句元 | 错误密度 |
|---|---|---|---|
| 胆碱受体阻断药 | 1 | 30 | 27% |
| 蜜蜂与蜂群 | 2 | 16 / 16 | 25% / 19% |
| 睡眠与节律 | 1 | 24 | 25% |

## 生成新地图

用 `skills/juyuan-map-forge` 这个 skill，把文本变成可玩的地图包：

1. 把 `skills/juyuan-map-forge` 复制到 `%USERPROFILE%\.dsh\skills\`
2. 在对话里让它处理你的文本，指定句元数和轮数
3. 产物写入 `public/maps/`，刷新页面即可看到

也可以手动跑：

```powershell
node skills/juyuan-map-forge/scripts/split.mjs 文本.txt .work/map-sentences.json
node skills/juyuan-map-forge/scripts/paginate.mjs .work/map-units.json .work/map-pages.json 12
node skills/juyuan-map-forge/scripts/build.mjs .work/map-meta.json
node scripts/validate-map.mjs public/maps/<packId>.json
```

校验不通过的地图不要放进 `public/maps/`。

## 目录

```
src/
  engine.ts      规则引擎（纯函数，原地修改状态）
  ai.ts          规则 AI（accuracy / expand / attack / strategy）
  store.ts       设置、进度、存档（localStorage）
  screens.tsx    主菜单、战役、战区、设置、文章回顾
  Game.tsx       对局界面
public/maps/     地图包 JSON + index.json
skills/          地图锻造 skill
scripts/         校验器、切句/分页/组装、AI 模拟、性能基准
docs/            截图
游戏方案.md       规则定稿
开发方案.md       实现方案与数值
```

## 已知限制

- 地图包需要手动放进 `public/maps/`，还没有导入界面
- 进度存在浏览器 localStorage，换设备不跟随
- 手机端没有「点击确认」，误触会直接花掉 AP
- 还没有 PWA 离线支持

## 开发脚本

```powershell
npm run typecheck                                    # 类型检查
npm run build                                        # 生产构建
node --experimental-strip-types scripts/check.mjs    # 引擎回归
node --experimental-strip-types scripts/simulate.mjs 1000 12 merge   # AI 对打 1000 局
node scripts/validate-map.mjs public/maps/bee.json   # 校验地图包
```
