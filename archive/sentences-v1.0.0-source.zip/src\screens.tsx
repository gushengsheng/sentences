import { useState } from 'react';
import { AI_PRESETS, presetById, type AiConfig } from './ai';
import type { MapDef, MapPack } from './engine';
import type { Difficulty, Progress, Settings } from './store';

export type Mode = 'ai' | 'hotseat';

// ---------- 主菜单 ----------

interface MenuProps {
  hasSave: boolean;
  totals: { cleared: number; total: number };
  onContinue: () => void;
  onPacks: () => void;
  onReading: () => void;
  onSettings: () => void;
}

export function MenuScreen({ hasSave, totals, onContinue, onPacks, onReading, onSettings }: MenuProps) {
  return (
    <div className="screen center">
      <div className="hero">
        <h1>sentences</h1>
        <p className="hero-sub">读得懂，才打得赢</p>
      </div>

      <div className="menu">
        {hasSave && (
          <button className="menu-btn primary" onClick={onContinue}>
            继续上次对局
          </button>
        )}
        <button className="menu-btn" onClick={onPacks}>
          选择战役
        </button>
        <button className="menu-btn" onClick={onReading}>
          文章回顾
        </button>
        <button className="menu-btn" onClick={onSettings}>
          设置
        </button>
      </div>

      <p className="muted menu-foot">
        已通关 {totals.cleared} / {totals.total} 个战区
      </p>
    </div>
  );
}

// ---------- 战役列表 ----------

interface PackListProps {
  packs: { id: string; title: string; maps: number }[];
  progress: Progress;
  onOpen: (packId: string) => void;
  onBack: () => void;
}

export function PacksScreen({ packs, progress, onOpen, onBack }: PackListProps) {
  function clearedCount(packId: string) {
    return Object.values(progress).filter(
      (r) => r.packId === packId && r.rating !== null,
    ).length;
  }

  return (
    <div className="screen">
      <header className="screen-head">
        <button className="back" onClick={onBack}>
          ← 返回
        </button>
        <h2>战役</h2>
      </header>

      <div className="cards">
        {packs.map((p) => {
          const done = clearedCount(p.id);
          return (
            <button key={p.id} className="card" onClick={() => onOpen(p.id)}>
              <div className="card-title">{p.title}</div>
              <div className="card-meta">
                {p.maps} 个战区 · 已通关 {done}
              </div>
              <div className="bar">
                <div
                  className="bar-fill"
                  style={{ width: `${p.maps ? (done / p.maps) * 100 : 0}%` }}
                />
              </div>
            </button>
          );
        })}
        {packs.length === 0 && <p className="muted">还没有地图包。</p>}
      </div>
    </div>
  );
}

// ---------- 战区列表 ----------

interface MapListProps {
  pack: MapPack;
  progress: Progress;
  sequentialUnlock: boolean;
  onPlay: (mapId: string) => void;
  onBack: () => void;
}

export function MapsScreen({ pack, progress, sequentialUnlock, onPlay, onBack }: MapListProps) {
  const ordered = [...pack.maps].sort((a, b) => a.order - b.order);

  return (
    <div className="screen">
      <header className="screen-head">
        <button className="back" onClick={onBack}>
          ← 返回
        </button>
        <h2>{pack.title}</h2>
      </header>

      <div className="cards">
        {ordered.map((m, i) => {
          const rec = progress[`${pack.id}::${m.id}`];
          const prev = ordered[i - 1];
          const prevCleared = !prev || !!progress[`${pack.id}::${prev.id}`]?.rating;
          const locked = sequentialUnlock && i > 0 && !prevCleared;

          return (
            <button
              key={m.id}
              className={`card ${locked ? 'locked' : ''}`}
              disabled={locked}
              onClick={() => onPlay(m.id)}
            >
              <div className="card-row">
                <span className="card-title">
                  {String(i + 1).padStart(2, '0')} · {m.title}
                </span>
                {rec?.rating && <span className="badge">{rec.rating}</span>}
                {locked && <span className="badge dim">未解锁</span>}
              </div>
              <div className="card-meta">
                {m.units.length} 句元 · {m.pages?.length ?? 1} 页 · 推荐 {m.recommendedRounds} 轮
                {rec?.plays ? ` · 已打 ${rec.plays} 局` : ''}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}

// ---------- 对局设置 ----------

export interface SetupResult {
  mode: Mode;
  presetId: string;
  custom: AiConfig;
  rounds: number;
  difficulty: Difficulty;
}

interface SetupProps {
  map: MapDef;
  onBack: () => void;
  onStart: (cfg: SetupResult) => void;
}

export function SetupScreen({ map, onBack, onStart }: SetupProps) {
  const [mode, setMode] = useState<Mode>('ai');
  const [presetId, setPresetId] = useState('normal');
  const [custom, setCustom] = useState<AiConfig>(() => ({ ...presetById('normal') }));
  const [rounds, setRounds] = useState(map.recommendedRounds || 12);

  const difficulty: Difficulty =
    presetId === 'custom' ? 'normal' : (presetId as Difficulty);

  return (
    <div className="screen">
      <header className="screen-head">
        <button className="back" onClick={onBack}>
          ← 返回
        </button>
        <h2>对局设置</h2>
      </header>

      <div className="setup">
        <div className="setup-map">
          <div className="card-title">{map.title}</div>
          <div className="card-meta">
            {map.units.length} 句元 · {map.pages?.length ?? 1} 页
          </div>
        </div>

        <label className="field">
          <span>模式</span>
          <select value={mode} onChange={(e) => setMode(e.target.value as Mode)}>
            <option value="ai">人机</option>
            <option value="hotseat">双人（同屏）</option>
          </select>
        </label>

        {mode === 'ai' && (
          <label className="field">
            <span>难度</span>
            <select
              value={presetId}
              onChange={(e) => {
                const id = e.target.value;
                setPresetId(id);
                if (id !== 'custom') setCustom({ ...presetById(id) });
              }}
            >
              {AI_PRESETS.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
              <option value="custom">自定义</option>
            </select>
          </label>
        )}

        {mode === 'ai' && presetId === 'custom' && (
          <div className="sliders">
            <label>
              准确度 <b>{custom.accuracy.toFixed(2)}</b>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={custom.accuracy}
                onChange={(e) => setCustom({ ...custom, accuracy: Number(e.target.value) })}
              />
            </label>
            <label>
              扩张 <b>{custom.expand.toFixed(2)}</b>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={custom.expand}
                onChange={(e) => setCustom({ ...custom, expand: Number(e.target.value) })}
              />
            </label>
            <label>
              攻击 <b>{custom.attack.toFixed(2)}</b>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={custom.attack}
                onChange={(e) => setCustom({ ...custom, attack: Number(e.target.value) })}
              />
            </label>
          </div>
        )}

        <label className="field slider-field">
          <span>
            回合数 <b>{rounds === 0 ? '不限' : rounds}</b>
          </span>
          <input
            type="range"
            min="0"
            max="50"
            step="1"
            value={rounds}
            onChange={(e) => setRounds(Number(e.target.value))}
          />
          <span className="muted hint">
            0 = 不限，打到棋盘占满或一方无法行动。每 3 轮一次腐化。
          </span>
        </label>

        <button
          className="menu-btn primary"
          onClick={() => onStart({ mode, presetId, custom, rounds, difficulty })}
        >
          开始对局
        </button>
      </div>
    </div>
  );
}

// ---------- 设置 ----------

interface SettingsProps {
  settings: Settings;
  onChange: (s: Settings) => void;
  progress: Progress;
  onResetProgress: () => void;
  onBack: () => void;
}

export function SettingsScreen({
  settings,
  onChange,
  progress,
  onResetProgress,
  onBack,
}: SettingsProps) {
  const [confirmReset, setConfirmReset] = useState(false);

  function exportProgress() {
    const blob = new Blob([JSON.stringify(progress, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'juyuan-progress.json';
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="screen">
      <header className="screen-head">
        <button className="back" onClick={onBack}>
          ← 返回
        </button>
        <h2>设置</h2>
      </header>

      <div className="setup">
        <label className="field slider-field">
          <span>
            UI 缩放 <b>{settings.uiScale.toFixed(2)}×</b>
          </span>
          <input
            type="range"
            min="0.85"
            max="1.4"
            step="0.05"
            value={settings.uiScale}
            onChange={(e) => onChange({ ...settings, uiScale: Number(e.target.value) })}
          />
        </label>

        <label className="field row">
          <span>配色</span>
          <select
            value={settings.theme}
            onChange={(e) => onChange({ ...settings, theme: e.target.value as 'dark' | 'light' })}
          >
            <option value="dark">深色</option>
            <option value="light">浅色（墨水屏）</option>
          </select>
        </label>

        <label className="field row">
          <span>动画反馈</span>
          <input
            type="checkbox"
            checked={settings.animation}
            onChange={(e) => onChange({ ...settings, animation: e.target.checked })}
          />
        </label>

        <label className="field row">
          <span>顺序解锁战区</span>
          <input
            type="checkbox"
            checked={settings.sequentialUnlock}
            onChange={(e) => onChange({ ...settings, sequentialUnlock: e.target.checked })}
          />
        </label>

        <div className="divider" />

        <div className="field row">
          <span>进度</span>
          <button onClick={exportProgress}>导出 JSON</button>
        </div>

        <div className="field row">
          <span>清空进度</span>
          {confirmReset ? (
            <span className="row">
              <button
                className="danger"
                onClick={() => {
                  onResetProgress();
                  setConfirmReset(false);
                }}
              >
                确认清空
              </button>
              <button onClick={() => setConfirmReset(false)}>取消</button>
            </span>
          ) : (
            <button onClick={() => setConfirmReset(true)}>清空…</button>
          )}
        </div>
      </div>
    </div>
  );
}


// ---------- 文章回顾 ----------

interface ReadingProps {
  pack?: MapPack;
  packs: { id: string; title: string; maps: number }[];
  onSelect: (id: string) => void;
  onBack: () => void;
}

export function ReadingScreen({ pack, packs, onSelect, onBack }: ReadingProps) {
  if (!pack) {
    return (
      <div className="screen">
        <header className="screen-head">
          <button className="back" onClick={onBack}>
            ← 返回
          </button>
          <h2>文章回顾</h2>
        </header>
        <p className="muted reading-hint">
          这里只显示正确原文，供对局外复习。对局中依然看不到原文。
        </p>
        <div className="cards">
          {packs.map((p) => (
            <button key={p.id} className="card" onClick={() => onSelect(p.id)}>
              <div className="card-title">{p.title}</div>
              <div className="card-meta">{p.maps} 个战区</div>
            </button>
          ))}
        </div>
      </div>
    );
  }

  const maps = [...pack.maps].sort((a, b) => a.order - b.order);

  return (
    <div className="screen">
      <header className="screen-head">
        <button className="back" onClick={onBack}>
          ← 返回
        </button>
        <h2>{pack.title}</h2>
      </header>

      <div className="reading">
        {maps.map((m) => {
          const paragraphs: { p: number; text: string }[] = [];
          for (const u of m.units) {
            const last = paragraphs[paragraphs.length - 1];
            if (last && last.p === u.paragraph) last.text += u.original;
            else paragraphs.push({ p: u.paragraph, text: u.original });
          }
          return (
            <section key={m.id}>
              <h3>
                {String(m.order).padStart(2, '0')} · {m.title}
              </h3>
              {paragraphs.map((pg) => (
                <p key={pg.p}>{pg.text}</p>
              ))}
            </section>
          );
        })}
      </div>
    </div>
  );
}
