import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { createMatch, apply, incomeOf, tally } from '../src/engine.ts';
import { validatePack } from './validate-map.mjs';

let failures = 0;
function ok(cond, msg) {
  if (!cond) {
    console.log('FAIL:', msg);
    failures++;
  }
}

const packPath = fileURLToPath(new URL('../public/maps/bee.json', import.meta.url));
const pack = JSON.parse(readFileSync(packPath, 'utf8'));

const v = validatePack(pack);
ok(v.ok, `地图包校验失败：${v.errors.join('; ')}`);
ok(pack.maps.length >= 2, '地图包应至少有两个战区');

// --- AP 不结转 ---
{
  let s = createMatch(pack, pack.maps[0].id, 9, 5);
  const side = s.turn;
  const before = s.ap[side];
  s = apply(s, { kind: 'endTurn' }).state;
  ok(s.ap[side] === 0, `回合结束后 ${side} 的 AP 应清零，实际 ${s.ap[side]}`);
  ok(before > 0, '首回合应有 AP');
}

// --- 不限轮数：棋盘占满即结束 ---
{
  let s = createMatch(pack, pack.maps[0].id, 0, 11);
  let guard = 0;
  while (!s.ended && guard++ < 5000) {
    const side = s.turn;
    const free = s.order.filter((id) => s.cells[id].owner === null);
    if (s.ap[side] >= 1 && free.length) {
      s = apply(s, { kind: 'claim', unitId: free[0] }).state;
      continue;
    }
    if (free.length === 0 && s.ap[side] < 1) {
      // 棋盘已满但还没结束，说明结束条件没触发
      ok(false, '棋盘占满后未结束');
      break;
    }
    s = apply(s, { kind: 'endTurn' }).state;
  }
  ok(s.ended, '不限轮数下棋盘占满应结束');
}

// --- 随机对局 ---
for (const rounds of [6, 9, 12]) {
  let s = createMatch(pack, pack.maps[1].id, rounds, 1000 + rounds);
  let guard = 0;
  while (!s.ended && guard++ < 20000) {
    const side = s.turn;
    const owned = s.order.filter((id) => s.cells[id].owner === side);
    const free = s.order.filter((id) => s.cells[id].owner === null);
    const enemy = s.order.filter((id) => s.cells[id].owner && s.cells[id].owner !== side);
    const r = Math.random();
    let action;
    if (s.ap[side] >= 2 && enemy.length && r < 0.15) {
      action = { kind: 'convert', unitId: enemy[Math.floor(Math.random() * enemy.length)] };
    } else if (s.ap[side] >= 1 && owned.length && r < 0.5) {
      const id = owned[Math.floor(Math.random() * owned.length)];
      const opt = s.units[id].options[Math.floor(Math.random() * 4)];
      action = { kind: 'correct', unitId: id, optionId: opt.id };
    } else if (s.ap[side] >= 1 && free.length) {
      action = { kind: 'claim', unitId: free[Math.floor(Math.random() * free.length)] };
    } else {
      action = { kind: 'endTurn' };
    }
    const res = apply(s, action);
    if (res.error) {
      ok(false, `非预期错误：${res.error}`);
      break;
    }
    s = res.state;
    ok(s.ap.A >= 0 && s.ap.B >= 0, 'AP 不应为负');
    for (const sd of ['A', 'B']) {
      const t = tally(s, sd);
      ok(incomeOf(s, sd) === Math.max(1, 1 + t.correct - t.wrong), `${sd} 收入公式不一致`);
    }
  }
  ok(s.ended, `${rounds} 轮对局应结束`);
  ok(s.winner === 'A' || s.winner === 'B', '应有胜者');
  ok(s.pulseIndex === Math.floor(rounds / 3), `${rounds} 轮应有 ${Math.floor(rounds / 3)} 次脉冲，实际 ${s.pulseIndex}`);
}

console.log(failures === 0 ? 'ALL OK' : `${failures} FAILURES`);
process.exit(failures === 0 ? 0 : 1);
