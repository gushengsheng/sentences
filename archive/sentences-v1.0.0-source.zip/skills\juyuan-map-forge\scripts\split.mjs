// 切句：文本 → [{ index, paragraph, text }]
// 用法：node split.mjs <文本文件> <输出.json>
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { dirname } from 'node:path';

const src = process.argv[2];
const out = process.argv[3];
if (!src || !out) {
  console.error('用法：node split.mjs <文本文件> <输出.json>');
  process.exit(2);
}

const text = readFileSync(src, 'utf8');

const END = new Set(['。', '！', '？', '；', '…', '!', '?', ';']);
const CLOSE = new Set(['”', '’', '」', '』', '）', ')', '》', '】']);
const SOFT = new Set(['，', ',', '：', ':', '、']);

const MIN_LEN = 12;
const MAX_LEN = 60;

function splitParagraph(p) {
  const parts = [];
  let buf = '';
  const chars = [...p];
  for (let i = 0; i < chars.length; i++) {
    const c = chars[i];
    buf += c;
    if (END.has(c)) {
      let j = i + 1;
      while (j < chars.length && (CLOSE.has(chars[j]) || END.has(chars[j]))) {
        buf += chars[j];
        j++;
      }
      i = j - 1;
      const s = buf.trim();
      if (s) parts.push(s);
      buf = '';
    }
  }
  if (buf.trim()) parts.push(buf.trim());
  return parts;
}

function refine(list) {
  // 不合并短句：切句点本身就是句末标点，每一段都是完整句。
  // 早期版本会把 <12 字的完整句并进上一句，导致丢句。
  const result = [];
  for (const s of list) {
    if (s.length <= MAX_LEN) {
      result.push(s);
      continue;
    }
    let buf = '';
    for (const ch of [...s]) {
      buf += ch;
      if (buf.length >= 30 && SOFT.has(ch)) {
        result.push(buf.trim());
        buf = '';
      }
    }
    if (buf.trim()) result.push(buf.trim());
  }
  return result;
}

const paragraphs = text
  .split(/\r?\n\s*\r?\n/)
  .map((p) => p.replace(/\s*\n\s*/g, '').trim())
  .filter(Boolean);

const sentences = [];
let index = 0;
paragraphs.forEach((p, pi) => {
  for (const s of refine(splitParagraph(p))) {
    sentences.push({
      id: `s${String(index + 1).padStart(2, '0')}`,
      index: index++,
      paragraph: pi + 1,
      text: s,
    });
  }
});

mkdirSync(dirname(out), { recursive: true });
writeFileSync(out, JSON.stringify(sentences, null, 2), 'utf8');
console.log(`切出 ${sentences.length} 句，${paragraphs.length} 段 → ${out}`);
