import { useEffect, useMemo, useState } from 'react';
import { presetById, type AiConfig } from './ai';
import Game from './Game';
import type { MapPack, MatchState } from './engine';
import {
  MenuScreen,
  PacksScreen,
  MapsScreen,
  SetupScreen,
  SettingsScreen,
  ReadingScreen,
  type Mode,
  type SetupResult,
} from './screens';
import {
  clearSave,
  loadProgress,
  loadSave,
  loadSettings,
  recordResult,
  saveProgress,
  saveSettings,
  type Difficulty,
  type Progress,
  type SaveFile,
  type Settings,
} from './store';

interface PackEntry {
  id: string;
  title: string;
  file: string;
  maps: number;
}

type Screen =
  | { name: 'menu' }
  | { name: 'packs' }
  | { name: 'maps'; packId: string }
  | { name: 'setup'; packId: string; mapId: string }
  | {
      name: 'game';
      packId: string;
      mapId: string;
      rounds: number;
      mode: Mode;
      presetId: string;
      difficulty: Difficulty;
      initialState?: MatchState;
      nonce: number;
    }
  | { name: 'reading'; packId?: string }
  | { name: 'settings' };

export default function App() {
  const [entries, setEntries] = useState<PackEntry[] | null>(null);
  const [packs, setPacks] = useState<Record<string, MapPack>>({});
  const [screen, setScreen] = useState<Screen>({ name: 'menu' });
  const [progress, setProgress] = useState<Progress>(() => loadProgress());
  const [settings, setSettings] = useState<Settings>(() => {
    const s = loadSettings();
    // 预览用：?theme=light / ?theme=dark 覆盖本次初始配色
    const q = new URLSearchParams(window.location.search).get('theme');
    return q === 'light' || q === 'dark' ? { ...s, theme: q } : s;
  });
  const [save, setSave] = useState<SaveFile | null>(() => loadSave());
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetch('/maps/index.json')
      .then((r) => {
        if (!r.ok) throw new Error(`index.json ${r.status}`);
        return r.json() as Promise<{ packs: PackEntry[] }>;
      })
      .then((idx) => setEntries(idx.packs))
      .catch((e) => setError(String(e?.message ?? e)));
  }, []);

  useEffect(() => {
    document.documentElement.dataset.theme = settings.theme;
    document.documentElement.style.setProperty('--ui-scale', String(settings.uiScale));
    document.documentElement.classList.toggle('no-anim', !settings.animation);
    saveSettings(settings);
  }, [settings]);

  useEffect(() => {
    saveProgress(progress);
  }, [progress]);

  // 调试入口：?debug=game 直接进入第一个战役的第二个战区（用于无头测试）
  useEffect(() => {
    if (!entries) return;
    if (new URLSearchParams(window.location.search).get('debug') !== 'game') return;
    const q = new URLSearchParams(window.location.search);
    const targetId = q.get('pack') ?? entries[0]?.id;
    if (!targetId) return;
    void (async () => {
      const pack = await ensurePack(targetId);
      const map = pack.maps[0];
      if (!map) return;
      setScreen({
        name: 'game',
        packId: targetId,
        mapId: map.id,
        rounds: map.recommendedRounds ?? 12,
        mode: 'ai',
        presetId: 'normal',
        difficulty: 'normal',
        nonce: Date.now(),
      });
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [entries]);

  async function ensurePack(packId: string): Promise<MapPack> {
    const cached = packs[packId];
    if (cached) return cached;
    const entry = entries?.find((e) => e.id === packId);
    if (!entry) throw new Error(`找不到地图包：${packId}`);
    const res = await fetch(`/maps/${entry.file}`);
    if (!res.ok) throw new Error(`${entry.file} ${res.status}`);
    const pack = (await res.json()) as MapPack;
    setPacks((prev) => ({ ...prev, [packId]: pack }));
    return pack;
  }

  async function openPack(packId: string) {
    try {
      await ensurePack(packId);
      setScreen({ name: 'maps', packId });
    } catch (e) {
      setError(String((e as Error)?.message ?? e));
    }
  }

  async function continueGame() {
    if (!save) return;
    try {
      await ensurePack(save.packId);
      setScreen({
        name: 'game',
        packId: save.packId,
        mapId: save.mapId,
        rounds: save.rounds,
        mode: save.mode,
        presetId: save.presetId,
        difficulty: save.difficulty ?? 'normal',
        initialState: save.state,
        nonce: Date.now(),
      });
    } catch (e) {
      setError(String((e as Error)?.message ?? e));
    }
  }

  function startGame(packId: string, mapId: string, cfg: SetupResult) {
    setScreen({
      name: 'game',
      packId,
      mapId,
      rounds: cfg.rounds,
      mode: cfg.mode,
      presetId: cfg.presetId,
      difficulty: cfg.difficulty,
      nonce: Date.now(),
    });
  }

  const totals = useMemo(() => {
    const total = entries?.reduce((s, e) => s + e.maps, 0) ?? 0;
    const cleared = Object.values(progress).filter((r) => r.rating !== null).length;
    return { cleared, total };
  }, [entries, progress]);

  if (error) {
    return (
      <div className="screen center">
        <h2>加载失败</h2>
        <p className="muted">{error}</p>
        <button className="menu-btn" onClick={() => setError(null)}>
          返回
        </button>
      </div>
    );
  }

  if (!entries) {
    return (
      <div className="screen center">
        <p className="muted">载入中…</p>
      </div>
    );
  }

  switch (screen.name) {
    case 'menu':
      return (
        <MenuScreen
          hasSave={!!save}
          totals={totals}
          onContinue={continueGame}
          onPacks={() => setScreen({ name: 'packs' })}
          onReading={() => setScreen({ name: 'reading' })}
          onSettings={() => setScreen({ name: 'settings' })}
        />
      );

    case 'packs':
      return (
        <PacksScreen
          packs={entries}
          progress={progress}
          onOpen={openPack}
          onBack={() => setScreen({ name: 'menu' })}
        />
      );

    case 'maps': {
      const pack = packs[screen.packId];
      if (!pack) {
        void ensurePack(screen.packId).catch((e) => setError(String(e)));
        return (
          <div className="screen center">
            <p className="muted">载入地图包…</p>
          </div>
        );
      }
      return (
        <MapsScreen
          pack={pack}
          progress={progress}
          sequentialUnlock={settings.sequentialUnlock}
          onPlay={(mapId) => setScreen({ name: 'setup', packId: screen.packId, mapId })}
          onBack={() => setScreen({ name: 'packs' })}
        />
      );
    }

    case 'setup': {
      const pack = packs[screen.packId];
      const map = pack?.maps.find((m) => m.id === screen.mapId);
      if (!pack || !map) {
        return (
          <div className="screen center">
            <p className="muted">载入中…</p>
          </div>
        );
      }
      return (
        <SetupScreen
          map={map}
          onBack={() => setScreen({ name: 'maps', packId: screen.packId })}
          onStart={(cfg) => startGame(screen.packId, screen.mapId, cfg)}
        />
      );
    }

    case 'game': {
      const pack = packs[screen.packId];
      if (!pack) {
        return (
          <div className="screen center">
            <p className="muted">载入中…</p>
          </div>
        );
      }
      const custom: AiConfig = presetById(screen.presetId);
      return (
        <Game
          key={`${screen.packId}:${screen.mapId}:${screen.nonce}`}
          pack={pack}
          mapId={screen.mapId}
          rounds={screen.rounds}
          mode={screen.mode}
          presetId={screen.presetId}
          custom={custom}
          difficulty={screen.difficulty}
          initialState={screen.initialState}
          onExit={() => {
            setScreen({ name: 'maps', packId: screen.packId });
            setSave(loadSave());
          }}
          onFinish={({ won, margin }) => {
            setProgress((p) =>
              recordResult(p, screen.packId, screen.mapId, screen.difficulty, won, margin),
            );
            setSave(null);
            clearSave();
          }}
        />
      );
    }

    case 'reading': {
      const pid = screen.packId;
      const pack = pid ? packs[pid] : undefined;
      if (pid && !pack) {
        void ensurePack(pid).catch((e) => setError(String(e)));
        return (
          <div className="screen center">
            <p className="muted">载入地图包…</p>
          </div>
        );
      }
      return (
        <ReadingScreen
          pack={pack}
          packs={entries}
          onSelect={(id) => setScreen({ name: 'reading', packId: id })}
          onBack={() => setScreen({ name: 'menu' })}
        />
      );
    }

    case 'settings':
      return (
        <SettingsScreen
          settings={settings}
          onChange={setSettings}
          progress={progress}
          onResetProgress={() => setProgress({})}
          onBack={() => setScreen({ name: 'menu' })}
        />
      );
  }
}
