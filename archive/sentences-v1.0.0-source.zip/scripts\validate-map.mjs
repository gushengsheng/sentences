// 地图包校验器
// 用法：node scripts/validate-map.mjs public/maps/bee.json
import { readFileSync } from 'node:fs';

const errors = [];
const warnings = [];

function fail(msg) {
  errors.push(msg);
}
function warn(msg) {
  warnings.push(msg);
}

function isStr(v) {
  return typeof v === 'string' && v.trim().length > 0;
}

export function validatePack(pack) {
  errors.length = 0;
  warnings.length = 0;

  if (pack.schemaVersion !== 1) fail('schemaVersion 必须为 1');
  if (!isStr(pack.id)) fail('pack.id 缺失');
  if (!isStr(pack.title)) fail('pack.title 缺失');
  if (!Array.isArray(pack.maps) || pack.maps.length === 0) fail('pack.maps 为空');
  if (Array.isArray(pack.maps)) {
    const mapIds = new Set();
    for (const map of pack.maps) {
      if (!isStr(map.id)) fail('地图 id 缺失');
      if (mapIds.has(map.id)) fail(`地图 id 重复：${map.id}`);
      mapIds.add(map.id);
      if (!isStr(map.title)) fail(`${map.id}：title 缺失`);
      if (typeof map.order !== 'number') fail(`${map.id}：order 缺失`);
      if (!Array.isArray(map.units) || map.units.length === 0) {
        fail(`${map.id}：units 为空`);
        continue;
      }

      const unitIds = new Set();
      let corrupt = 0;
      for (const u of map.units) {
        const tag = `${map.id}/${u.id ?? '?'}`;
        if (!isStr(u.id)) fail(`${tag}：id 缺失`);
        if (unitIds.has(u.id)) fail(`${tag}：id 重复`);
        unitIds.add(u.id);
        if (!isStr(u.original)) fail(`${tag}：original 缺失`);
        if (!isStr(u.wrongDisplay)) fail(`${tag}：wrongDisplay 缺失`);
        if (!isStr(u.correctOption)) fail(`${tag}：correctOption 缺失`);
        if (!Array.isArray(u.wrongOptions) || u.wrongOptions.length !== 3) {
          fail(`${tag}：wrongOptions 必须为 3 项`);
        } else if (!u.wrongOptions.every(isStr)) {
          fail(`${tag}：wrongOptions 含空项`);
        }
        if (typeof u.corruptNow !== 'boolean') fail(`${tag}：corruptNow 必须为布尔`);
        if (u.corruptNow === true) corrupt++;

        const optSet = new Set([u.correctOption, ...(u.wrongOptions ?? [])]);
        if (optSet.size !== 4) fail(`${tag}：4 个选项不唯一`);
        if (optSet.has(u.original)) fail(`${tag}：原文与某个选项重复`);
        if (optSet.has(u.wrongDisplay)) fail(`${tag}：wrongDisplay 与某个选项重复`);
        if (u.original === u.wrongDisplay) fail(`${tag}：原文与篡改版相同`);

        const lens = [u.original, u.wrongDisplay, u.correctOption, ...(u.wrongOptions ?? [])]
          .filter(isStr)
          .map((s) => s.length);
        if (lens.length === 5) {
          const max = Math.max(...lens);
          const min = Math.min(...lens);
          if (max / min > 1.3) warn(`${tag}：5 个文本长度差 ${Math.round((max / min - 1) * 100)}%`);
        }
      }

      const density = corrupt / map.units.length;
      if (density < 0.15 || density > 0.35) {
        warn(`${map.id}：错误密度 ${(density * 100).toFixed(0)}% 超出 15–35%`);
      }

      if (Array.isArray(map.pages) && map.pages.length > 0) {
        const covered = new Set();
        for (const p of map.pages) {
          if (!Array.isArray(p.unitIds) || p.unitIds.length === 0) {
            fail(`${map.id}/${p.id}：页为空`);
            continue;
          }
          for (const id of p.unitIds) {
            if (!unitIds.has(id)) fail(`${map.id}/${p.id}：引用了不存在的句元 ${id}`);
            if (covered.has(id)) fail(`${map.id}/${p.id}：句元 ${id} 被多页覆盖`);
            covered.add(id);
          }
        }
        for (const id of unitIds) {
          if (!covered.has(id)) fail(`${map.id}：句元 ${id} 没有归入任何页`);
        }
      }
    }
  }

  return {
    ok: errors.length === 0,
    errors,
    warnings,
    stats: Array.isArray(pack.maps)
      ? pack.maps.map((m) => ({
          mapId: m.id,
          units: m.units?.length ?? 0,
          pages: m.pages?.length ?? 0,
          corruptPct: m.units?.length
            ? Math.round((m.units.filter((u) => u.corruptNow).length / m.units.length) * 100)
            : 0,
        }))
      : [],
  };
}

const isMain = process.argv[1] && process.argv[1].endsWith('validate-map.mjs');
if (isMain) {
  const file = process.argv[2];
  if (!file) {
    console.error('用法：node scripts/validate-map.mjs <地图包.json>');
    process.exit(2);
  }
  let pack;
  try {
    pack = JSON.parse(readFileSync(file, 'utf8'));
  } catch (e) {
    console.error('JSON 解析失败：', e.message);
    process.exit(2);
  }
  const res = validatePack(pack);
  for (const s of res.stats) {
    console.log(`  ${s.mapId}: ${s.units} 句元, ${s.pages} 页, 错误 ${s.corruptPct}%`);
  }
  for (const w of res.warnings) console.warn('WARN ', w);
  for (const e of res.errors) console.error('ERROR', e);
  console.log(res.ok ? `PASS (${res.warnings.length} warnings)` : `FAIL (${res.errors.length} errors)`);
  process.exit(res.ok ? 0 : 1);
}
