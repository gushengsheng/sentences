import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  // 监听所有网卡，手机才能通过局域网 IP 访问
  server: { host: '0.0.0.0', port: 5175, strictPort: true },
});
